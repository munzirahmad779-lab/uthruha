// Ukur precision/recall pemeriksa ortografi pada korpus uji berlabel.
// Metode kalimat: kalimat salah = tepat bila ada temuan aturan yang diharapkan;
// kalimat bersih = keliru bila menghasilkan temuan tingkat "kesalahan".
import { periksaOrtografi } from "../lib/engine/orthografi";

const SALAH: { teks: string; aturan: string }[] = [
  { teks: "ذهب الطالب الى المدرسه صباحا.", aturan: "Ta marbuta" },        // المدرسه → المدرسة
  { teks: "هذه مساله مهمه في البحث.", aturan: "Ta marbuta" },            // مساله/مهمه
  { teks: "قرأت الكتاب الذى اهداه لي صديقي.", aturan: "Ejaan baku" },     // الذى → الذي
  { teks: "يدرس الطالب الاسلام في الجامعة.", aturan: "Ejaan baku" },    // الاسلام → الإسلام
  { teks: "هاذا الكتاب مهم للباحثين.", aturan: "Ejaan baku" },          // هاذا → هذا,
  { teks: "يتناول البحث مشكلة التربيه الحديثه.", aturan: "Ta marbuta" }, // التربيه/الحديثه
  { teks: "حضر الطلاب الى القاعه مبكرا.", aturan: "Ta marbuta" },
  { teks: "كانت النتيجه مرضيه للجميع.", aturan: "Ta marbuta" },
  { teks: "سوف نناقش هذه القضيه بالتفصيل.", aturan: "Ta marbuta" },      // القضيه
  { teks: "العلم نور والجهل ظلام .", aturan: "Tanda baca" },             // spasi sebelum titik
  { teks: "ما هي أهداف البحث ؟", aturan: "Tanda baca" },                 // spasi sebelum ؟
  { teks: "لقد جمع الباحث البيانات ، ثم حللها.", aturan: "Tanda baca" },// spasi sebelum ،
  { teks: "ذهب ذهب الطالب إلى المكتبة.", aturan: "Kata terulang" },
  { teks: "سجل الطالب في alجامعة الجديدة.", aturan: "Huruf campur" },   // campur DALAM satu kata,
  { teks: "استخدم الباحث 25 طالبا في العينة.", aturan: "Angka Latin" },
  { teks: "قال (الباحث في كتابه أن العلم مهم.", aturan: "Kurung tidak seimbang" },
];

const BERSIH: string[] = [
  "ذهب الطالب إلى المدرسة صباحًا.",
  "تتناول هذه الدراسة مشكلة التربية الحديثة في المدارس.",
  "قال الباحث إن النتائج واضحة ومهمة.",
  "ما هي أهداف البحث؟",
  "لقد جمع الباحث البيانات، ثم حللها بعناية.",
  "استخدم الباحث خمسةً وعشرين طالبًا في العينة.",
  "العلم نور والجهل ظلام.",
  "حضر الطلاب إلى القاعة مبكرًا وجلسوا بهدوء.",
  "كانت النتيجة مرضية للجميع.",
  "سوف نناقش هذه القضية بالتفصيل في الفصل التالي.",
];

let terdeteksi = 0;
const meleset: string[] = [];
for (const s of SALAH) {
  const lap = periksaOrtografi(s.teks);
  const kena = lap.temuan.some((t) => t.aturan === s.aturan);
  if (kena) terdeteksi++;
  else meleset.push(`${s.aturan}: ${s.teks} → temuan: ${lap.temuan.map((t) => t.aturan).join(", ") || "(tidak ada)"}`);
}
let fp = 0;
let fpLunak = 0;
const bersihKena: string[] = [];
for (const t of BERSIH) {
  const lap = periksaOrtografi(t);
  const salah = lap.temuan.filter((x) => x.tingkat === "kritis");
  if (salah.length > 0) { fp++; bersihKena.push(`${t} → ${salah.map((x) => x.aturan).join(", ")}`); }
  else if (lap.temuan.length > 0) fpLunak++;
}
const recall = terdeteksi / SALAH.length;
const ketelitianBersih = 1 - fp / BERSIH.length;
console.log(`Korpus: ${SALAH.length} kalimat salah berlabel + ${BERSIH.length} kalimat bersih.`);
console.log(`Recall (kesalahan berlabel yang tertangkap): ${terdeteksi}/${SALAH.length} = ${(recall * 100).toFixed(0)}%`);
console.log(`Kalimat bersih tanpa temuan kesalahan: ${BERSIH.length - fp}/${BERSIH.length} = ${(ketelitianBersih * 100).toFixed(0)}%`);
console.log(`Kalimat bersih dengan temuan lunak (saran/info) saja: ${fpLunak}/${BERSIH.length}`);
if (meleset.length) console.log("Meleset:\n- " + meleset.join("\n- "));
if (bersihKena.length) console.log("Bersih tapi kena:\n- " + bersihKena.join("\n- "));
